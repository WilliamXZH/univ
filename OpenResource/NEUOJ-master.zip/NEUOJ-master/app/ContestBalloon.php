<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContestBalloon extends Model
{
    protected $table = "contest_balloons";
}
