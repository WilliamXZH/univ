<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainUser extends Model
{
    protected $table = "train_users";
}
