<h1>Password ResetConfirmation</h1>
<div>
    You are recieving this email because someone use this email
    address asked for a password, if it's not you, just omit it
    the request will discard in 10 minutes
</div>
<div>
    If you request for passowrd reset, Please Click the link below
    <a href="http://202.118.31.226/auth/reset?token={{ $passwordReset->token }}">Reset Password</a>
</div>

<div>NEUOJ</div>