<link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!-- Include Editor style. -->
<link href="/css/summernote.css" rel="stylesheet" type="text/css" />

<!-- Include Code Mirror style -->
<link rel="stylesheet" href="/css/codemirror.min.css">
