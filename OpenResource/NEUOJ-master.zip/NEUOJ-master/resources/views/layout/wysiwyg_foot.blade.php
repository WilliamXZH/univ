<script type="text/javascript" src="/js/summernote.min.js"></script>
<script type="text/javascript" src="/js/codemirror.min.js"></script>
<script type="text/javascript" src="/js/xml.min.js"></script>


<script>
    $(function() {
    	$('.summernote').summernote({
  	height: 240,                 // set editor height
  	placeholder:'请输入文章内容',
  	focus: true                  // set focus to editable area after initializing summernote
	});
    });
</script>

