require('./bootstrap');
require('weui');

const mobile = new Vue({
    el: '#mobile',
});
