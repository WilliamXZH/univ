$("#new_connection").replaceWith('{!! escape_javascript(view("connection.create")) !!}')
