//
// Created by john on 2016/11/14.
//

#ifndef TEST2_QUEUENODE_H
#define TEST2_QUEUENODE_H


#include "carGuild.h"

class QueueNode {
public:
    zanInode *data;
    QueueNode *link;
};


#endif //TEST2_QUEUENODE_H
