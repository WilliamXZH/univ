//
// Created by john on 2016/11/14.
//

#ifndef TOUR_STACKNODE_H
#define TOUR_STACKNODE_H

#include "carGuild.h"

class StackNode {
public:
    zanInode *data;
    StackNode *link;
};


#endif //TOUR_STACKNODE_H
