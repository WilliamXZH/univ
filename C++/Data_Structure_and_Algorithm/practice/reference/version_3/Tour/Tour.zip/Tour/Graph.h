//
// Created by john on 2016/11/14.
//

#ifndef TOUR_GRAPH_H
#define TOUR_GRAPH_H

#include "create.h"

class Graph {
    AdjList adjlist;
    int vexnum, arcnum;
};


#endif //TOUR_GRAPH_H
