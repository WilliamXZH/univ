package pers.william.service;

import pers.william.model.Matrix;

public class Reader {

	public Matrix getData(String pathname){
		Matrix matrix = new Matrix();
		
		
		
		return matrix;
		
	}
}
