package pers.william.test;

import java.util.ArrayList;
import java.util.List;

public class SimilarityTest {
	
	public void testSim(){
		List<Integer> list1 = new ArrayList<>();
	}
}
