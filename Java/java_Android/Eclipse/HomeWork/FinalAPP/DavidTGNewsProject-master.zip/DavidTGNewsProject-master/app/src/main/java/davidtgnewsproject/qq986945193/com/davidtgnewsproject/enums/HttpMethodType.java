package davidtgnewsproject.qq986945193.com.davidtgnewsproject.enums;

/**
 * @author ：程序员小冰
 * @新浪微博 ：http://weibo.com/mcxiaobing
 * @GitHub: https://github.com/QQ986945193
 * @CSDN博客: http://blog.csdn.net/qq_21376985
 */
public enum HttpMethodType {
    GET,
    POST,
}
