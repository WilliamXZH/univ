package davidtgnewsproject.qq986945193.com.davidtgnewsproject.callback;

/**
 * 处理OkHttp获取到json字符串
 */
public interface OnGetOkhttpStringListener {
    void onResponse(String result);
}
