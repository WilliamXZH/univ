package davidtgnewsproject.qq986945193.com.davidtgnewsproject.constants;

/**
 * @author ：程序员小冰
 * @新浪微博 ：http://weibo.com/mcxiaobing
 * @GitHub: https://github.com/QQ986945193
 * @CSDN博客: http://blog.csdn.net/qq_21376985
 */
public class Urls {
    public static final String CSDN_BLOG_DAVID = "http://blog.csdn.net/qq_21376985";
    public static final String SINA_WEIBO = "http://weibo.com/mcxiaobing";
    public static final String GITHUB_DAVID = "https://github.com/QQ986945193";
    public static final String GIT_OSCHINA_DAVID = "http://git.oschina.net/MCXIAOBING";
    public static final String CSDN_DAVID = "http://my.csdn.net/qq_21376985";

    public static final String SPORTS = "http://apis.baidu.com/txapi/tiyu/tiyu";
    public static final String TECH = "http://apis.baidu.com/txapi/keji/keji";
    public static final String APPLE = "http://apis.baidu.com/txapi/apple/apple";

}
