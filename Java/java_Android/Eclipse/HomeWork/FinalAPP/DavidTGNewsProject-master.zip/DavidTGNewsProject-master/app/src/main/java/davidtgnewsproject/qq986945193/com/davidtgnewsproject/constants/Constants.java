package davidtgnewsproject.qq986945193.com.davidtgnewsproject.constants;

/**
 * @author ：程序员小冰
 * @新浪微博 ：http://weibo.com/mcxiaobing
 * @GitHub: https://github.com/QQ986945193
 * @CSDN博客: http://blog.csdn.net/qq_21376985
 * <p/>
 * 项目名称：小冰新闻
 */
public class Constants {
    public static final String LOG_TAG = "qq986945193";
    /*这里是使用百度api的时候，需要传递的参数名*/
    public static final String API_KEY = "apikey";
    /*这里是使用百度API的时候所要传递的自己的秘钥*/
    public static final String API_KEY_SECRET = "";
}
