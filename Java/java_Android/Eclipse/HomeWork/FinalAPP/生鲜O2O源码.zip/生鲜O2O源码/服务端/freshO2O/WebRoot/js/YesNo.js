function YesNo(){
	var b=window.confirm("是否确认删除？");
	if(!b){
		return false;
	}
}