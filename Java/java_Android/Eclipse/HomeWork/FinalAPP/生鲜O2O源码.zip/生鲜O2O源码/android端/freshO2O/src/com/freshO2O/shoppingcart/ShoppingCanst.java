package com.freshO2O.shoppingcart;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCanst {
	public static List<ShopBean> list = new ArrayList<ShopBean>();			//购物车数据集合
	public static List<AddressBean> addressList;//收件人信息集合
}
