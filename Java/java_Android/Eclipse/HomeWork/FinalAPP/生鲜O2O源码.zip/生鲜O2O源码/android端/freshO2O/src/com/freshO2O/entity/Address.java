package com.freshO2O.entity;

public class Address {
	
}
