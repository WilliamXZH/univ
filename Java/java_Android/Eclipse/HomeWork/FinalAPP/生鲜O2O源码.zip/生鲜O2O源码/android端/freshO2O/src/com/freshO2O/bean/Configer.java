package com.freshO2O.bean;

public class Configer {
	public static final boolean DEBUG = true; // 定义系统的运行状态

	public static final String SERVER_HOST = "http://192.168.1.103:8080/freshO2O"; // 定义服务端地址
}
