package com.latu.qingcheng123.vo;

public class AdsItem {
	public String categoryId;	// 栏目ID
	public String adsId;		// 广告ID
	public String title;		// 广告title
	public String imgURL;		// 广告图片URL
}
