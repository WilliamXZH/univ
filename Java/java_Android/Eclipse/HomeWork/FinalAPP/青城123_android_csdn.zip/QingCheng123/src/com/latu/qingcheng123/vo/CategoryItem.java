package com.latu.qingcheng123.vo;

/**
 * 栏目种类
 * @author qidalatu
 *
 */
public class CategoryItem {
	public String categoryID;		// 栏目ID
	public String categoryName;		// 栏目名称
}
