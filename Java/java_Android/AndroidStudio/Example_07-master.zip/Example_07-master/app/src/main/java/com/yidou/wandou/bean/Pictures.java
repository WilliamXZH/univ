package com.yidou.wandou.bean;

import java.util.List;

/**
 * Created by Administrator on 2016/11/11.
 */

public class Pictures
{
    /**
     * status : true
     * total : 101254
     * tngou : [{"count":28,"description":"灏忚瘈绐嶅皬璐村＋锛氳眴鑵愮敤鍐锋按涓嬮攨鐒繃鎵嶄細灏介噺淇濇寔鍘熺姸锛屽彟澶栭渶瑕佸井鐏參鐐栦互鍏嶈繃鐏鐑�","fcount":0,"food":"浜旇姳鑲�,娴峰甫,璞嗚厫,鑺辩敓娌�,鑺遍洉閰�,鑰佹娊,楦＄矇","id":11444,"images":"","img":"/cook/080222/b6906dec37b6ce10886396a93ea141f3.jpg","keywords":"浜旇姳鑲� 娴峰甫 璞嗚厫 绾㈢儳鑲� 鑺遍洉閰� ","name":"娴峰甫璞嗚厫鐐栬倝","rcount":0},{"count":28,"description":"鏉愭枡閰辨补鑶�2澶у寵锛岃晝鑼勯叡3澶у寵锛岀硸2澶у寵锛屼箤閱�2澶у寵锛岄娌�1澶у寵锛岃懕鏈�傞噺锛屽鏈�傞噺锛岃挏鏈�傞噺锛岄鑿滄湯閫傞噺锛岃荆妞掗�傞噺鍋氭硶1銆佸皢鎵�鏈夋潗鏂欐贩鍚堟媽鍖�鍗冲彲","fcount":0,"food":"閰辨补鑶�,钑冭寗閰�,涔岄唻,棣欐补,棣欒彍,杈ｆ","id":29717,"images":"","img":"/cook/080301/3f92bafc31b4341b4be41bfe637d3aae.jpg","keywords":"澶у寵 閫傞噺 鏉愭枡 閰辨补鑶� 钑冭寗閰� ","name":"浜斿懗閰�","rcount":0},{"count":28,"description":"锛堟兂鍚冨埌缇庡懗灏辨瘮杈冨簾鐏樋鍢匡級灏忚瘈绐嶉璋辫惀鍏伙細鐚倠鏉¤倝锛堜簲鑺辫倝锛夛細鐚倝鍚湁涓板瘜鐨勪紭璐ㄨ泲鐧借川鍜屽繀闇�鐨勮剛鑲吀锛屽苟鎻愪緵琛�绾㈢礌锛堟湁鏈洪搧锛夊拰淇冭繘閾佸惛鏀剁殑鍗婅儽姘ㄩ吀锛岃兘鏀瑰杽缂洪搧鎬ц传琛�锛涘叿鏈夎ˉ鑲惧吇琛�锛屾粙闃存鼎鐕ョ殑鍔熸晥锛涗絾鐢变簬鐚倝涓儐鍥洪唶鍚噺鍋忛珮锛屾晠鑲ヨ儢浜虹兢鍙婅鑴傝緝楂樿�呬笉瀹滃椋�","fcount":0,"food":"浜旇姳鑲�,濮滀笣,鑰佹娊,鏂欓厭,澶ф枡,姊呭共鑿�","id":11447,"images":"","img":"/cook/080222/153fbfe2a54ec0bc24738a341348218b.jpg","keywords":"浜旇姳鑲� 濮滀笣 澶ф枡 璋冪悊 姊呭共鑿� ","name":"姊呰彍鎵ｈ倝","rcount":0},{"count":28,"description":"鏉愭枡閰辨补鑶�2澶у寵锛岀硸1澶у寵锛屾按1澶у寵锛岃挏娉�1澶у寵鍋氭硶1銆佸皢閰辨补鑶忋�佺硸鍜屾按鎼呮媽鍧囧寑鍚庯紝鍐嶅姞鍏ヨ挏娉ヨ交杞绘悈鎷屽嵆鍙�","fcount":0,"food":"閰辨补鑶�,钂滄偿","id":29718,"images":"","img":"/cook/080301/c1a7d105acf52dd9bdf92c18e68e8ca8.jpg","keywords":"澶у寵 閰辨补鑶� 鎼呮媽 钂滄偿 鐢ㄩ�� ","name":"纰楃部閰�","rcount":0},{"count":28,"description":"鑼跺共鍛崇編棣欒姵锛屽瘜鏈夐煣鎬э紝鑹叉辰缇庤锛屽舰鐘舵柟涓旇杽锛屽埆鍏蜂竴鏍硷紝缁忔祹瀹炴儬锛岄┌鍚嶅洓鏂癸紝鏋佸彈缇や紬娆㈣繋","fcount":0,"food":"绱犻浮,閰辨补,棣欏彾,鍏,妗傜毊,鑼跺彾,澶ч","id":11453,"images":"","img":"/cook/080222/545bc104e6d30843f9f579fcbb06a398.jpg","keywords":"绱犻浮 鐣岄 鑹叉辰 鐭崇煻 鑷充粖宸叉湁 ","name":"鑲夐棣欒尪骞�","rcount":0},{"count":28,"description":"杩欐槸閽堝澶уⅷ楸艰倝姣旇緝鍘氱殑涓�绉嶅仛娉曪紝鐣寗娌欏徃涔熷彲鐢ㄨタ绾㈡熆鑷繁璋冨埗锛屾柟娉曟槸灏嗚タ绾㈡熆缁炵锛岀啲鑷虫垚鐨勶紝鍛抽亾涔熷緢濂�","fcount":0,"food":"澧ㄩ奔,鐣寗娌欏徃,钂滆搲","id":11454,"images":"","img":"/cook/080222/3caf79a3857cd9d2b712fca95283b84c.jpg","keywords":"瑗跨孩鏌� 鐣寗 鍊掑叆 鍛抽亾 灏戣 ","name":"閰哥敎鍙ｇ殑澧ㄩ奔鐐�","rcount":0},{"count":28,"description":"鏉愭枡绾㈣倝鑺辫洡锛岄潰鏉¤繃姘存播骞插鐢紝钁卞垏鑺憋紝钂滃墎鎴愯挏钃夊仛娉�1","fcount":0,"food":"鑺辫洡,闈㈡潯,鑺�,钂滆搲","id":11461,"images":"","img":"/cook/080222/a0382a3d4596f0e58b7b8e7209c82367.jpg","keywords":"閿呬腑 闈㈡潯 姘翠腑 钂滆搲 璧烽攨 ","name":"闀垮绾㈣洡钂�","rcount":0},{"count":28,"description":"楂樿鍘嬬殑骞撮緞鐗瑰緛锛氫竴鑸殢骞撮緞鐨勫楂樿�屽鍔狅紱绮剧鍥犵礌锛氱幇浠ｇぞ浼氱珵浜夋縺鐑堬紝涓�浜涗汉绮剧鍘嬪姏澶с�佸け鐪犮�佹姂閮佺棁閮戒細寮曡捣楂樿鍘�","fcount":0,"food":"姝︽槍楸�,鐢熸娊","id":11472,"images":"","img":"/cook/080222/f11852746fca7ce3cb9c59ce4ac33436.jpg","keywords":"楂樿鍘� 鐤剧梾 鍥犵礌 姝︽槍楸� 楗涔犳儻 ","name":"娓呰捀姝︽槍楸�","rcount":0},{"count":28,"description":"p;鐩墠甯傚満鐪嬪埌鐨勯笨楸兼湁涓ょ锛氫竴绉嶆槸韬共閮ㄨ緝鑲ュぇ鐨勯笨楸硷紝瀹冪殑鍚嶇О鍙�滄灙涔岃醇鈥濓紱涓�绉嶆槸韬共閮ㄧ粏闀跨殑楸块奔锛屽畠鐨勫悕绉板彨鈥滄煍楸尖�濓紝灏忕殑鏌旈奔淇楀悕鍙�滃皬绠\u2032粩鈥�","fcount":0,"food":"濮滀笣,楸块奔","id":11473,"images":"","img":"/cook/080222/552a3f72190cdf7ad956a9f5b43796c5.jpg","keywords":"楸块奔 杞綋鍔ㄧ墿 韬綋 楂樿儐鍥洪唶琛�鐥� 骞查儴 ","name":"姘寸叜楸块奔","rcount":0},{"count":28,"description":"鏉愭枡钁辨湯1澶у寵锛屽鏈�1灏忓寵锛岃泲榛�1涓仛娉�1銆佸皢鏂伴矞铔嬮粍鎵撳叆纰椾腑锛屽姞鍏ヨ懕鏈拰濮滄湯鎷屽寑鍗冲彲","fcount":0,"food":"铔嬮粍","id":29737,"images":"","img":"/cook/080301/09d48c5d1ed6d77cdd1f5c1c8ecb9b42.jpg","keywords":"濮滄湯 铔嬮粍 鏂伴矞 灏忓寵 鏉愭枡 ","name":"鐏攨铇告枡","rcount":0},{"count":28,"description":"灏忚瘈绐嶅皬璐村＋锛氬崡鐡滄槸浣庤剛鑲�佷綆鐑噺銆佸瘜鍚矖绾ょ淮銆佺淮鐢熺礌A鍜岃榛勯唶褰撻噺闈炲父涓板瘜鐨勫仴搴烽鐗╋紝瀵圭粡甯稿姞鐝�佺啲澶滅殑鐢佃剳涓�鏃忓吇鑲濇姢鐩�佹鼎鑲犲噺鑴傛湁寰堝ソ鐨勪綔鐢紝鐗瑰埆鏄崡鐡滃惈閽惧挨澶氾紝骞朵笖閽鹃挔姣斾緥銆侀挋闀佹瘮渚嬮潪甯稿悎鐞嗭紝閫傚悎蹇冭剳琛�绠＄柧鐥呫�佺硸灏跨梾鍜岄珮琛�鍘嬫偅鑰呯殑钀ュ吇椋熺枟","fcount":0,"food":"鍗楃摐,楦¤泲,鑼撮,鑲夐,鍗佷笁棣�,楦＄矇","id":11477,"images":"","img":"/cook/080222/53f36d7057e429d352792cfbb5660a4d.jpg","keywords":"鍗楃摐 鑼撮 楗哄瓙 鑲夐 闈炲父涓板瘜 ","name":"鑼撮榛勯噾楗�","rcount":0},{"count":28,"description":"鍙戠幇瀹堕噷鏈変竴鍙扮儰绠憋紝鐪熸槸涓�浠舵尯缇庡緱浜嬪効锛氬湪鎯冲伔鎳掔殑鏃跺�欙紝鎶婅厡濂界殑鑲夊晩锛岃彍鍟婏紝棣掑ご鐗囦粈涔堢殑寰�閲岄潰涓�鎵旓紝涓嶅埌20鍒嗛挓锛屽氨鍙樺嚭涓�椁愮編鍛筹紱蹇冩儏濂界殑鏃跺�欙紝鍦ㄥ鎱㈡參鎶樿吘鐑樼剻锛屽仛涓�绡皬椁愬寘锛岄ゼ骞诧紝铔嬬硶浠�涔堢殑锛屾叞鍔充竴涓嬭嚜宸卞拰瀹朵汉锛屽湪鐢滆湝鐨勬皵鍛充腑锛屽績瀹夌悊寰楃殑璁╃敓娲绘參涓嬫潵","fcount":0,"food":"濂舵补,楦¤泲,鍙彲绮�,灏忚嫃鎵�,鐧借姖楹�","id":11478,"images":"","img":"/cook/080222/140a6a75be9d39bd972b6f80cfeb8c41.jpg","keywords":"鐧借姖楹� 鐑樼剻 浠�涔堢殑 鍔犲叆 灏忚嫃鎵� ","name":"宸у厠鍔涜姖楹婚ゼ骞�","rcount":0},{"count":28,"description":"鍏堝皢闈㈡潯鐓啛锛屽皢鎵�鏈夎皟鍛虫枡鎼呮媽鍧囧寑锛屽�掑叆鐓ソ鐨勯潰鏉\u2032腑锛屾媽鍖�鍗冲彲锛涜嫢鏄敤娌归潰锛屽彲鎾掍簺娌硅懕閰ワ紝澧炲姞娌归潰婊戞鼎鐨勫彛鎰�","fcount":0,"food":"鐚补,涔岄唻,閰辨补,鍛崇簿,棣欐补,钁辫姳","id":29739,"images":"","img":"/cook/080301/211d69d028662deab7f0716009e8970a.jpg","keywords":"灏忓寵 娌归潰 灏戣 闈㈡潯 鍐嶅姞涓� ","name":"铓濇补骞查潰閰�","rcount":0},{"count":28,"description":"鏉愭枡铓濇补1灏忓寵锛岄娌瑰皯璁革紝钁辫姳1澶у寵鍋氭硶1銆佸厛灏嗛潰鏉＄叜鐔燂紱2銆佸皢鎵�鏈夎皟鍛虫枡鎼呮媽鍧囧寑锛屽�掑叆鐓ソ鐨勯潰鏉\u2032腑锛屾媽鍖�鍗冲彲","fcount":0,"food":"铓濇补,棣欐补,钁辫姳","id":29740,"images":"","img":"/cook/080301/22393321f9f1862ce403c6c788e27532.jpg","keywords":"闈㈡潯 璋冨懗鏂� 灏忓寵 鏉愭枡 鎵�鏈� ","name":"涓�鑸共闈㈤叡","rcount":0},{"count":28,"description":"鏉愭枡妗戞す鏋滈叡2澶у寵锛岀櫧閱�3澶у寵锛屾灉绯�1/2澶у寵鍋氭硶1銆佷笌鎵�鏈夋潗鏂欐媽鍖�鍗冲彲浣跨敤","fcount":0,"food":"妗戞す鏋滈叡,鐧介唻,鏋滅硸","id":29743,"images":"","img":"/cook/080301/0c42c44fe5898df2d77f38a1c2493ce3.jpg","keywords":"澶у寵 鏉愭枡 鐢熻彍娌欐媺 鐧介唻 鍧囧彲 ","name":"妗戞す閱嬮叡","rcount":0},{"count":28,"description":"鏈�鍚庝竴澶╋紝鍜屽コ鍙嬬浉绾﹀湪鍘﹀ぇ闄勮繎涓�瀹跺挅鍟￠锛屾秷纾ㄤ簡浣欎笅鐨勬偁闂叉椂鍏夛細寰堝枩娆㈣繖鏍烽潤璋ф煍杞殑涓嬪崍锛屽拰濂冲弸鍦ㄥ涵闄腑锛屽枬鍠濊尪锛屽皬鍧愰棽鑱�","fcount":0,"food":"榛勬补,绾㈢硸,浣庣瓔闈㈢矇,灏忚嫃鎵�,鍏ㄨ泲娑�,钁¤悇骞�","id":11485,"images":"","img":"/cook/080222/caf69a055ab69c904b083dd05db6d1e0.jpg","keywords":"绾㈢硸 钁¤悇骞� 鍧囧寑 灏忚嫃鎵� 鏈�鍚� ","name":"绾㈢硸濂囨櫘","rcount":0},{"count":28,"description":"灏忚瘈绐嶆澘鏍椾笅閿呭悗锛屽敖閲忓皯鍘诲姩寮癸紝鍚﹀垯锛屽ソ鐨勬澘鏍椾細杩囩儌鍚庢暎鎺夛紝鍚冭捣鏉ヤ笉鏂逛究锛屼篃涓嶅ソ鐪�","fcount":0,"food":"鏉挎牀,涓夊眰鑲�,棣欏彾,鍏,鍐扮硸","id":11486,"images":"","img":"/cook/080222/65dfd9992b3642d65810dff87f182835.jpg","keywords":"鏉挎牀 鏍楀瓙 鍊掑叆 闂峰埌 鍏 ","name":"姣涙牀瀛愮孩鐑ц倝","rcount":0},{"count":28,"description":"灏忚瘈绐�1銆佸彇铏炬偿鍖呰９鑺濆＋鐗囩殑鏃跺�欙紝鎵嬩笂娌句竴鐐规按锛屾搷浣滆捣鏉ュ氨涓嶄細绮樹簡2銆佽櫨娉ヨ灏嗚姖澹墖瀹屽叏鍖呰９浣忥紝鍚﹀垯涓嬫补閿呯偢鐨勬椂鍊欎細闇查鐖嗘祮:锛�3銆佸鏋滄兂瑕佹湁鎷変笣鐨勬晥鏋滐紝鑺濆＋鐗囧彲浠ユ崲鎴愬仛鎵硅惃甯哥敤鐨勯┈鑻忛噷鎷夎姖澹�4銆佺偢濂界殑铏剧悆瓒佺儹鐩存帴浜敤灏卞緢缇庡懗锛屼篃鍙互鎼厤鐣寗閰辨垨鑰呮嘲寮忕敎杈ｉ叡澧炲姞椋庡懗","fcount":0,"food":"澶ц櫨,鏂圭墖鑺濆＋,鏂欓厭,鐢熸娊,骞叉穩绮�,铔嬫竻,闈㈠寘绯�","id":11487,"images":"","img":"/cook/080222/fdb70dac3ead3b33976031126175dfbd.jpg","keywords":"灏忓嫼 闈㈠寘 铔嬫竻 灏忕墖 鍖呰９ ","name":"鑺濆＋铏剧悆","rcount":0},{"count":28,"description":"杩欎釜铔嬬硶鍗峰晩锛岀畝鍗曞ソ鍋氬張濂藉悆锛屾渶杩戞湁鐐逛笂鐦惧暒~~淇烘妸绯栧拰娌圭殑鐢ㄩ噺鍑忚嚦鏈�浣庯紝鎴愬搧鏁堟灉杩樻槸鐩稿綋涓嶉敊婊磣~鍋氭硶濡備笅锛氭潗鏂欏父娓╅浮铔�4涓紝浣庣矇85g锛岀硸30G锛岀墰濂�40G锛屾补40G锛岀洂涓�鐐圭偣锛岀櫧閱嬪嚑婊达紝鑲夋澗锛屽壀纰庣殑娴疯嫈閫傞噺鍋氭硶1","fcount":0,"food":"楦¤泲,浣庣矇,鐗涘ザ,鐧介唻,鑲夋澗,娴疯嫈","id":11491,"images":"","img":"/cook/080222/af27926a58546522fbf7fb6d556f91ee.jpg","keywords":"铔嬬硶 娌圭焊 铔嬬櫧 鍘熷洜 鑷繁 ","name":"鑲夋澗娴疯嫈铔嬬硶鍗�","rcount":0},{"count":28,"description":"鏉愭枡铓濇补3澶у寵锛岄粦閱�1澶у寵锛岀硸1澶у寵锛岀櫧鑳℃绮�1灏忓寵锛岀背閰�1澶у寵锛屾按2澶у寵锛屽お鐧界矇1灏忓寵锛岄娌瑰皯璁稿仛娉�1銆佸皢鎵�鏈夋潗鏂欐斁鍏ラ攨涓紱2銆佷竴璧疯皟鍖�鐓紑鏀惧噳鍗冲彲","fcount":0,"food":"铓濇补,榛戦唻,鐧借儭妞掔矇,绫抽厭,澶櫧绮�,棣欐补","id":29756,"images":"","img":"/cook/080301/8a7684513c05db11fbdb647e4b3445a8.jpg","keywords":"澶у寵 瀹繚 鏉愭枡 灏忓寵 澶櫧绮� ","name":"瀹繚閰�","rcount":0}]
     */

    private boolean status;
    private int total;
    /**
     * count : 28
     * description : 灏忚瘈绐嶅皬璐村＋锛氳眴鑵愮敤鍐锋按涓嬮攨鐒繃鎵嶄細灏介噺淇濇寔鍘熺姸锛屽彟澶栭渶瑕佸井鐏參鐐栦互鍏嶈繃鐏鐑�
     * fcount : 0
     * food : 浜旇姳鑲�,娴峰甫,璞嗚厫,鑺辩敓娌�,鑺遍洉閰�,鑰佹娊,楦＄矇
     * id : 11444
     * images :
     * img : /cook/080222/b6906dec37b6ce10886396a93ea141f3.jpg
     * keywords : 浜旇姳鑲� 娴峰甫 璞嗚厫 绾㈢儳鑲� 鑺遍洉閰�
     * name : 娴峰甫璞嗚厫鐐栬倝
     * rcount : 0
     */

    private List<TngouBean> tngou;

    public boolean isStatus()
    {
        return status;
    }

    public void setStatus(boolean status)
    {
        this.status = status;
    }

    public int getTotal()
    {
        return total;
    }

    public void setTotal(int total)
    {
        this.total = total;
    }

    public List<TngouBean> getTngou()
    {
        return tngou;
    }

    public void setTngou(List<TngouBean> tngou)
    {
        this.tngou = tngou;
    }

    public static class TngouBean
    {
        private int count;
        private String description;
        private int fcount;
        private String food;
        private int id;
        private String images;
        private String img;
        private String keywords;
        private String name;
        private int rcount;

        public int getCount()
        {
            return count;
        }

        public void setCount(int count)
        {
            this.count = count;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

        public int getFcount()
        {
            return fcount;
        }

        public void setFcount(int fcount)
        {
            this.fcount = fcount;
        }

        public String getFood()
        {
            return food;
        }

        public void setFood(String food)
        {
            this.food = food;
        }

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public String getImages()
        {
            return images;
        }

        public void setImages(String images)
        {
            this.images = images;
        }

        public String getImg()
        {
            return img;
        }

        public void setImg(String img)
        {
            this.img = img;
        }

        public String getKeywords()
        {
            return keywords;
        }

        public void setKeywords(String keywords)
        {
            this.keywords = keywords;
        }

        public String getName()
        {
            return name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public int getRcount()
        {
            return rcount;
        }

        public void setRcount(int rcount)
        {
            this.rcount = rcount;
        }
    }
}
