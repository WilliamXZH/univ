package com.yidou.wandou;

/**
 * Created by Administrator on 2016/11/11.
 */

public class Constances
{
    //聚合数据，apikey申请地址：https://www.juhe.cn/docs/api/id/235
    public static final String KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
    public static final String NEWS_URL = "http://v.juhe.cn/toutiao/";
    public static final String TOP = "top";
    public static final String SHI = "shishang";
    public static final String JUN = "junshi";
    public static final String Pictures = "http://apis.baidu.com/tngou/cook/";
    public static final String IMGS = "http://tnfs.tngou.net/image";
}
