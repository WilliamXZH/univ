package com.group3.po;

import java.sql.Timestamp;

public class tbOrder {

	private Integer id;
	private String userId;
	private String memberName;
	private Integer trainId;
	private Integer depatureId;
	private Integer destinationId;
	private Integer payStatus;
	private Float cost;
	private Timestamp time;
	private Integer ofdStatus;
	private String payMethod;

	public tbOrder() {
		super();
	}

	public tbOrder(Integer id, String userId, String memberName, Integer trainId, Integer depatureId,
			Integer destinationId, Integer payStatus, Float cost, Timestamp time, Integer ofdStatus, String payMethod) {
		super();
		this.id = id;
		this.userId = userId;
		this.memberName = memberName;
		this.trainId = trainId;
		this.depatureId = depatureId;
		this.destinationId = destinationId;
		this.payStatus = payStatus;
		this.cost = cost;
		this.time = time;
		this.ofdStatus = ofdStatus;
		this.payMethod = payMethod;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Integer getTrainId() {
		return trainId;
	}

	public void setTrainId(Integer trainId) {
		this.trainId = trainId;
	}

	public Integer getDepatureId() {
		return depatureId;
	}

	public void setDepatureId(Integer depatureId) {
		this.depatureId = depatureId;
	}

	public Integer getDestinationId() {
		return destinationId;
	}

	public void setDestinationId(Integer destinationId) {
		this.destinationId = destinationId;
	}

	public Integer getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

	public Timestamp getTime() {
		return time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public Integer getOfdStatus() {
		return ofdStatus;
	}

	public void setOfdStatus(Integer ofdStatus) {
		this.ofdStatus = ofdStatus;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	@Override
	public String toString() {
		return "tbOrder [id=" + id + ", userId=" + userId + ", memberName=" + memberName + ", trainId=" + trainId
				+ ", depatureId=" + depatureId + ", destinationId=" + destinationId + ", payStatus=" + payStatus
				+ ", cost=" + cost + ", time=" + time + ", ofdStatus=" + ofdStatus + ", payMethod=" + payMethod + "]";
	}
}
