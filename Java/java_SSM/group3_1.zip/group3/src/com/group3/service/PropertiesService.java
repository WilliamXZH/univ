package com.group3.service;

public interface PropertiesService {
	
	public Float getTicketTypeQuot(Integer ticketTypeId);
	
	public Float getTicketTypeQuot(String ticketType);
	
	public Float getUserTypeQuot(String userType);
	
}
