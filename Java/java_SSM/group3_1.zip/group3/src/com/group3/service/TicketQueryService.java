package com.group3.service;

import java.util.List;

import com.group3.po.Station;
import com.group3.po.TicketQueryCondition;
import com.group3.vo.TrainVO;

public interface TicketQueryService {

	public Station getStationByName(String name);
	
	public List<TrainVO> queryTicket(TicketQueryCondition conditions);
	
}
