package com.group3.service;

import java.util.List;

import com.group3.po.Order;
import com.group3.vo.OrderInfo;


public interface OrderService {
	
	public List<OrderInfo> selectOrder(String condition,String start,String end);

	public List<OrderInfo> selectOrder2(String start, String end);

	public List<OrderInfo> selectOrder3(String condition, String start, String end);

	public List<OrderInfo> selectOrder4(String start, String end);
	
	public boolean addOrder(Order newOrder);

}
