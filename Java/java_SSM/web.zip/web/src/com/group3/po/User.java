package com.group3.po;

public class User {
	String name;
	String password;
	
	public User(){
		super();
	}
	
	public User(String name, String password) {
		super();
		this.name = name;
		this.password = password;
		
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


//	@Override
//	public String toString() {
//		return "User [id=" + id + ", password=" + password + "]";
//	}
//	
	
}
