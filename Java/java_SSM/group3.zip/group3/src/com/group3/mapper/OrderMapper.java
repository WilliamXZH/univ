package com.group3.mapper;

import java.util.List;
import java.util.Map;

import com.group3.po.Order;
import com.group3.vo.OrderInfo;

public interface OrderMapper {

	public List<OrderInfo> selectOrder(Map<String, String> map);

	public List<OrderInfo> selectOrder2(Map<String, String> map);

	public List<OrderInfo> selectOrder3(Map<String, String> map);

	public List<OrderInfo> selectOrder4(Map<String, String> map);
	
	public int addOrder(Order newOrder);
	
	public Integer selectCurrentOrderId(Map<String, Object> paramMap);
	
	public int payForOrder(Integer orderId,String payMethod,Integer ifDeliver);
}
