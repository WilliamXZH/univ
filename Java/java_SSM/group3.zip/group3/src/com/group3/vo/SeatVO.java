package com.group3.vo;

public class SeatVO {

	private Integer seatId;
	private Integer depature;
	private Integer destination;
	
	
}
