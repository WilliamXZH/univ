package com.group3.service;

import org.springframework.stereotype.Service;

import com.group3.po.Order;
import com.group3.vo.OrderInfo;
import com.group3.vo.OrderVO;

@Service
public interface RefundTicketService {
	public boolean refundTicket(String orderNum);
	public boolean changeMyStatus(String seatNum,int startid,int destationid,int Trainid); 
	public OrderVO showMyOrder(String orderNum);

}
