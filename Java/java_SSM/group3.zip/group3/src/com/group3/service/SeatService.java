package com.group3.service;

import java.util.List;
import com.group3.po.SeatInfo;
import com.group3.po.SeatQueryCondition;

public interface SeatService {
	public List<SeatInfo> allocSeat(SeatQueryCondition condition);
}
