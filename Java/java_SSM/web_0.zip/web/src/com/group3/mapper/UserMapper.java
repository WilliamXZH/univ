package com.group3.mapper;
import com.group3.po.User;

public interface UserMapper {

	public User userLogin(User user);

}
