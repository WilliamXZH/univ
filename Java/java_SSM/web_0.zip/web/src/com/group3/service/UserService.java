package com.group3.service;


import com.group3.po.User;

public interface UserService {
	
public User userLogin(User user);
	
}
