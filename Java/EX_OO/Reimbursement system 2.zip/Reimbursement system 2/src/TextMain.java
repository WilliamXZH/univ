import base.Drug;

public class TextMain {
	public static void main(String[] args) {
		System.out.println(new Drug("��˾ƥ��", "��ʵ��ʵ��", null, null, null, null, null, 12, 23, null, null, null, null, null,
				null, null, null, null, null, null, null, null, null));
		System.out.println(new Drug("��˾ƥ�ְ�", "��ʵ��ʵ��", "asdasfasf", null, null, null, null, 12, 23, null, null, null,
				null, null, null, null, null, null, null, null, null, null, null));
	}
}
