package experiment;
class CoffeeBrewer extends Product{
	String model;
	String waterSupply;
	int numberOfCups;
	CoffeeBrewer(String code, String description, double price, String model, String waterSupply, int numberOfCups) {
		super(code, description, price);
		this.model=model;
		this.waterSupply=waterSupply;
		this.numberOfCups=numberOfCups;
	}
	String getModel(){
		return this.model;
	}
	String getWaterSupply(){
		return this.waterSupply;
	}
	int getNumberOfCups(){
		return this.numberOfCups;
	}
	public String toString(){
		return code + "_" + description + "_" + price + "_"
                + model + "_" + waterSupply + "_" + numberOfCups;
	}
}