package experiment;
class Coffee extends Product{
	String origin;
	String roast;
	String flavor;
	String aroma;
	String acidity;
	String body;
	Coffee(String code, String description, double price, String origin, String roast, String flavor,
			String aroma, String acidity, String body) {
		super(code,description,price);
		this.origin=origin;
		this.roast=roast;
		this.flavor=flavor;
		this.aroma=aroma;
		this.acidity=acidity;
		this.body=body;
	}
	public String getOrigin(){
		return this.origin;
	}
	public String getRoast(){
		return this.roast;
	}
	public String getFlavor(){
		return this.flavor;
	}
	public String getAroma(){
		return this.aroma;
	}
	public String getAcidity(){
		return this.acidity;
	}
	public String getBody(){
		return this.body;
	}
	public String toString(){
		return code + "_" + description + "_" + price + "_" + origin
                + "_" + roast + "_" + flavor + "_" + aroma + "_"
                + acidity + "_" + body;
	}
}