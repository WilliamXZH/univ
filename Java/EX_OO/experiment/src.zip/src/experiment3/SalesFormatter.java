package experiment3;

import experiment2.Sales;

public interface SalesFormatter {
	public String formatSales(Sales sales);
}
