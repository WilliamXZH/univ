package experiment;

import java.util.*;

public class Order implements Iterable<OrderItem>{
	List<OrderItem> items=new ArrayList<OrderItem>();
	void addItem(OrderItem oderItem){
		items.add(oderItem);
	}
	void removeItem(OrderItem orderItem){
		items.remove(orderItem);
	}
	OrderItem getItem(Product product){
		for(OrderItem orderItem:items){
			if(orderItem.getProduct()==product)return orderItem;
		}
		return null;
	}
	public Iterator<OrderItem> iterator(){
		Iterator<OrderItem> iter=items.iterator();
		return iter;
	}
	int getNumberOfItems(){
		return items.size();
	}
	double getTotalCost(){
		double totalcost=0;
		for(OrderItem orderItem:items)
			totalcost+=orderItem.getValue();
		return totalcost;
	}
}
