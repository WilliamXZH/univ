package experiment;

import java.util.*;

public class Catalog implements Iterable<Product>{
	List<Product> products;
	public Catalog() {
		products=new ArrayList<Product>();
	}
	public void addProduct(Product product){
		products.add(product);
	}
	Product getProduct(String code){
		for(Product product:products){
			if(product.getCode().equals(code))return product;
		}
		return null;
	}
	public Iterator<Product> iterator(){
		return this.products.iterator();
	}
	int getNumberOfProducts(){
		return products.size();
	}
}
