package experiment;

import java.util.*;

public class Sales implements Iterable<Order>{
	List<Order> orders=new ArrayList<Order>();
	void addOrder(Order order){
		orders.add(order);
	}
	public Iterator<Order> iterator(){
		return orders.iterator();
	}
	int getNumberOfOrders(){
		return orders.size();
	}
}
