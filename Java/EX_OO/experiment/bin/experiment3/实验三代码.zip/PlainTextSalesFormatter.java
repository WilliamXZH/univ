package experiment3;

import experiment.*;
import java.util.Iterator;

public class PlainTextSalesFormatter implements SalesFormatter{
	private static PlainTextSalesFormatter singletonInstance=new PlainTextSalesFormatter();
	private PlainTextSalesFormatter(){
	}
	public String formatSales(Sales sales){
		String print= "";
		int num=0;
		for(Order order:sales){
			print+="----------------------\n"+"Order "+(++num)+"\n\n";
		    for(OrderItem orderItem:order){
		     	print+=orderItem.toString()+"\n";
		    }
		print+="\n"+"Total="+order.getTotalCost()+"\n";
		}
		return print;
	}
	public static PlainTextSalesFormatter getSingletonInstance(){
		return singletonInstance;
	}
}
