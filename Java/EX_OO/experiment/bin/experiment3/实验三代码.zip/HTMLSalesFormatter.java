package experiment3;

import experiment.*;

public class HTMLSalesFormatter implements SalesFormatter{
	private static HTMLSalesFormatter singletonInstance=new HTMLSalesFormatter();
	public static HTMLSalesFormatter getSingletonInstance(){
		return singletonInstance;
	}
	public String formatSales(Sales sales){
		String print="\n<html>\n<body>\n<center><h2>Orders</h2></center>\n";
		for(Order order:sales){
			print+="\t<hr>\n\t<h4>Total="+order.getTotalCost()+"</h4>\n";
			for(OrderItem orderitem:order){
				print+="\t<p>\n\t\t<b>code:</b>"+orderitem.getProduct().getCode()+"<br>\n"+
						"\t\t<b>quantity:</b>"+orderitem.getQuantity()+"<br>\n"+
						"\t\t<b>price:</b>"+orderitem.getProduct().getPrice()+"\n\t</p>\n";
			}
		}
		print+="</body>\n</html>";
		return print;
	}
}
