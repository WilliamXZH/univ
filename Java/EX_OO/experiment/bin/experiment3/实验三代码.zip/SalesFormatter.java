package experiment3;

import experiment.Sales;

public interface SalesFormatter {
	public String formatSales(Sales sales);
}
