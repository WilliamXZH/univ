package experiment3;

import experiment.*;

public class XMLSalesFormatter implements SalesFormatter{
	private static XMLSalesFormatter singletonInstance=new XMLSalesFormatter();
	public String formatSales(Sales sales){
		String print="\n<Sales>\n";
		for(Order order:sales)
        {
            print+="\t<Order total=\""+order.getTotalCost()+"\">\n";
            for(OrderItem orderitem:order)
            {
            	print+="\t\t<OrderItem quantity=\""+orderitem.getQuantity()+"\" price=\""+
            			orderitem.getProduct().getPrice()+"\">"+orderitem.getProduct().getCode()+"</OrderItem>\n";
            }
            print+="\t</Order>\n";
		}
		print+="</Sales>\n";
		return print;
	}
	public static XMLSalesFormatter getSingletonInstance(){
		return singletonInstance;
	}
}
