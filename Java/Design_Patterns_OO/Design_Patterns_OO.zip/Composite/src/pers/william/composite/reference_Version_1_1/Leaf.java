package pers.william.composite.reference_Version_1_1;

public class Leaf implements Node{

	public void operation() {
		// TODO Auto-generated method stub
		
	}

}
