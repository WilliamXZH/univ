package pers.william.composite.thirdexper_2;

public interface Builder {
	public Node build(int totalDepth);
}
