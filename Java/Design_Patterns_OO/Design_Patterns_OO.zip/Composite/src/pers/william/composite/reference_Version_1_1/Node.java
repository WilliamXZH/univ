package pers.william.composite.reference_Version_1_1;

public interface Node {
	public void operation();
}
