package pers.william.decorator.secondexper;

public interface Component {
	public void draw();
}
