package pers.william.decorator.reference;

public interface Component {
	public void draw();
}
