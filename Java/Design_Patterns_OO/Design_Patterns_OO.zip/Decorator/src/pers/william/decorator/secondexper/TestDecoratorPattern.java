package pers.william.decorator.secondexper;

public class TestDecoratorPattern {
	public static void main(String[] args){
		Client client=new Client();
		client.client();
		System.out.println("\n\nTest finished!");
	}
}
