package pers.william.decorator.reference_2;

public class TextView implements VisualComponent {

	public void draw() {
		// TODO Auto-generated method stub
		
	}

}
