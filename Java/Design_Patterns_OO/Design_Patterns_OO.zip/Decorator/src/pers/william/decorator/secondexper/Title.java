package pers.william.decorator.secondexper;

public class Title implements Component{

	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("\t\t����\tmannings");
	}

}
