package pers.william.decorator.reference_2;

public interface VisualComponent {
	public void draw();

}
