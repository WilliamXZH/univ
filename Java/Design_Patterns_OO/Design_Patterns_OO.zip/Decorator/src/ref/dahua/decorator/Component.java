package ref.dahua.decorator;

public interface Component {

	public void Operation();
	
}
