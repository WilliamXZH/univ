package ref.dahua.decorator;

public class ConcreteComponent implements Component{

	public void Operation() {
		// TODO Auto-generated method stub
		System.out.println("�������Ĳ���");
		
	}

}
