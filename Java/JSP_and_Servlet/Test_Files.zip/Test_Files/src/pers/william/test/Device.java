package pers.william.test;

public class Device {
	public static String getDeviceSQL(int dvs[],int ids[],int dvstoid[],int dvstyp[]){
		int n=dvs.length;
		int cn=ids.length;
		
		String tmp="prompt Loading DEVICE...\r\n";
		
		for(int i=0;i<n;i++){
			boolean flag=true;
			while(flag){
				flag=false;
				dvs[i]=Utils.getRandomInt()%1000;
				for(int j=0;j<i;j++){
					if(dvs[i]==dvs[j]){
						flag=true;
						break;
					}
				}
			}
			
			dvstyp[i]=1;
			dvstoid[i]=ids[Utils.getRandomInt()%cn];
			flag=true;
			for(int j=0;j<i;j++){
				if(dvstoid[i]==dvstoid[j]){
					dvstyp[i]++;
				}
			}
			
			
			tmp+="insert into DEVICE (deviceid, clientid, type, balance) values ("
					+dvs[i]+","+dvstoid[i]+",\'"+Utils.IntToChar2(dvstyp[i])
					+"\',"+(Utils.getRandomInt()%300-100)+");\r\n";

			if(i%100==99)tmp+="commit;\r\n"
					+"prompt "+(i+1)+" records committed...\r\n";
			
		}
		
		
		return tmp;
	}
}
