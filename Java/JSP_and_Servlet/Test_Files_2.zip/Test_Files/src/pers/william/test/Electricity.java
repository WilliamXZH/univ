package pers.william.test;

public class Electricity {
	public static String getElectricity(int dvs[]){
		int n=dvs.length;
		
		String tmp="prompt Loading ELECTRICITY...\r\n";

		String date="2016"+Utils.IntToChar2(Utils.getRandomInt()%12+1);
		for(int i=0;i<n;i++){
			tmp+="insert into ELECTRICITY (id, deviceid, yearmonth, snum) values ("
					+dvs[i]+","+dvs[i]+",\'"+date+"\',"
					+(Utils.getRandomInt()%100000+10000)+");\r\n";
			if(i%100==99)tmp+="commit;\r\n"
					+"prompt "+(i+1)+" records committed...\r\n";
		}
		
		return tmp;
	}
}
