package pers.william.test;

public class Receivables {
	public static String getReceivablesSQL(int dvs[]){
		int n=dvs.length;
		
		String tmp="prompt Loading RECEIVABLES...\r\n";

		String date="2016"+Utils.IntToChar2(Utils.getRandomInt()%6+1);
		
		for(int i=0;i<n;i++){
			tmp+="insert into RECEIVABLES (id, yearmonth, deviceid, basicfee, flag)"
					+"values ("+i+",\'"+date+"\',"+dvs[i]+", "+Utils.getRandomInt()%300
					+", \'"+Utils.getRandomInt()%2+"\');\r\n";

			if(i%100==99)tmp+="commit;\r\n"
					+"prompt "+(i+1)+" records committed...\r\n";
		}
		
		
		return tmp;
	}
}
